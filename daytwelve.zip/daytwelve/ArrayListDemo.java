package daytwelve;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		List <String> obj= new LinkedList<>();
		obj.add("India");
		System.out.println(obj);
		
		
		ArrayList<String> obj1 = new ArrayList<>();
		obj.add("USA");
		System.out.println(obj1);
	}

}
